#include "students.h"
#include "students.c"



int main(void)
{
  printf("WELCOME");
  int uniqe=0;
  st* list;
  int stid;
  list=NULL;
    int code;
    FILE* fp;


    if (!(fp = fopen("results.txt", "r")))
    {
      printf("\n");
        printf( "The file does not exist, I am creating a text file with the name: result \n");
       fp=fopen("results.txt","w");
       fclose(fp);
       fp=fopen("results.txt","r");
    }


    int counter=0;
    int id;
    char name[100];

    while((fscanf(fp,"%d\n%s",&id,name))!=EOF){

    list=Load(list,id,name);
    counter++;
    }

    fclose(fp);

if(list==NULL){
  printf("\n");
  printf("There isn't any student registered in the list yet,\nadd a new students by pressing '1'\n");
  printf("\n");
}

    for (;;)
    {
        printf("Enter the code: \n");
        printf("1 -ADD NEW STUDENT DETAILS- \n");
        printf("2 -SEARCH STUDENT DETAILS- \n");
        printf("3 -DISPLAY REPORT OF ALL STUDENTS- \n");
        printf("4 -DELETE STUDENT DETAILS- \n");
        printf("5 -CHANGE STUDENTS DETAILS- \n");
        printf("6 -EXIT- \n");
        scanf(" %d", &code);

        switch (code)
        {
            case 1:
              list = AddStudent(list,stid);
Save(list);
list=NULL;
if (!(fp = fopen("results.txt", "r")))
{
  printf("\n");
    printf( "The file does not exist, I am creating a text file with the name: result \n");
   fp=fopen("results.txt","w");
   fclose(fp);
   fp=fopen("results.txt","r");
}


int counter=0;
int id;
char name[100];

while((fscanf(fp,"%d\n%s",&id,name))!=EOF){

list=Load(list,id,name);
counter++;
}

fclose(fp);
                break;

            case 2:
            FindStudent(list);
                break;

            case 3:
            printf("\n");
                PrintStudents(list);
                break;


            case 4:
            {
           list=DeleteStudent(list);
Save(list);


                break;
          }

          case 5:
          {
            list=UpdateStudent(list);
Save(list);

            break;
          }

            case 6:
            {

              exit(1);
            }

            default:
                printf("False code\n");
        }

        printf("\n");
    }
    free(list);

return 0;
}
