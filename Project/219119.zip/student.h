#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAXSTRING

typedef struct STUDENTS
{
    int studentID;
    char studentName[MAXSTRING];
    struct STUDENTS *next;
}st;


st* Search(int studentID,st* list);
st* AddStudent(st* list,int id);
void FindStudent(st* list);
void PrintStudents(st *list);
void Save(st *list);
st* Load(st* list,int id,char name[]);
st* DeleteStudent(st* list);
st* UpdateStudent(st* list);
